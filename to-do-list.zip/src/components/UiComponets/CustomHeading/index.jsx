import React from 'react'

function CustomHeading(props) {
    return (
        <div className="custom-heading">
            <h5 {...props} className={`${headingClass} ${className}`}>{props.children}</h5>
        </div>
    )
}

export default CustomHeading;
