import React from 'react'

const CustomButton = () => {
    return (
        <button className={`${buttonClass} ${className}`}>
            {props.children}
        </button>
    )
}

export default CustomButton
