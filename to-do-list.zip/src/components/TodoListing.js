import React, { useState } from "react";
import { useTodoStore } from "../store/store";

function TodoListing({ item }) {
  const updateStatus = useTodoStore((state) => state.updateStatus);
  const removeTodo = useTodoStore((state) => state.removeTodo);

  const handleCheckClick = () => {
    updateStatus(item.id, "green-bg");
  };

  const handleCrossClick = () => {
    updateStatus(item.id, "red-bg");
  };

  const handleDeleteCheck = () => {
    removeTodo(item.id);
  };

  return (
    <ul>
      <li className={`list-item ${item.status}`}>
        {item.text}

        <span className="icons">
          {(item.status === "green-bg" || item.status === null) && (
            <i
              class="fa-duotone fa-solid fa-check"
              onClick={handleCheckClick}
            ></i>
          )}
          {(item.status === "red-bg" || item.status === null) && (
            <i class="fa-solid fa-xmark" onClick={handleCrossClick}></i>
          )}
          <i
            className="fa-solid fa-trash-can icon-delete"
            onClick={handleDeleteCheck}
          ></i>
        </span>
      </li>
    </ul>
  );
}

export default TodoListing;
