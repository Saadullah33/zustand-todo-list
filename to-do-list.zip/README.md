Todo App with Zustand and LocalStorage

This is a simple and interactive Todo App built with React and Zustand for state management. The app allows users to:

Add Tasks: Enter a task in the input field and add it to the list.

Mark Status: Mark tasks as completed or not using status indicators (✓ for green and ✕ for red).

Delete Tasks: Remove tasks from the list with a delete button.

Persist Data: All tasks and their statuses are saved in localStorage, ensuring the data persists across page reloads.
The app uses Zustand with the persist middleware to manage the state effectively and store it in localStorage for a seamless user experience.
